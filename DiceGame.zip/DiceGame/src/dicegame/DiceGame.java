package dicegame;

import java.util.Scanner;
import java.util.Arrays;

public class DiceGame {
    private Player player1;
    private Player player2;
    
    private Scanner scanner;
    private Dice[] dice;
    private final int MAX_ROLLS = 3;
    private static final int MAX_TURNS = 7;
    private int currentRound;

    public DiceGame() {
         player1 = new Player("Player 1", MAX_TURNS);
        player2 = new Player("Player 2", MAX_TURNS);
        
        scanner = new Scanner(System.in);
        dice = new Dice[5];
        for (int i = 0; i < dice.length; i++) {
            dice[i] = new Dice();
        }
        currentRound = 1;
    }

  private void playTurn(Player player) {
    System.out.println(player.getName() + "'s turn:");
    int rollCount = 0;
    boolean[] diceSetAside = new boolean[dice.length];
    StringBuilder currentRollSequence = new StringBuilder();

    while (rollCount < MAX_ROLLS) {
        rollDice(diceSetAside);
        System.out.println("Current roll: " + displayDice());
        System.out.println("Choose a category, 'r' to reroll, or 'd' to defer the throw: ");
        String input = scanner.nextLine();

        if ("r".equalsIgnoreCase(input) && rollCount < MAX_ROLLS - 1) {
            rollCount++;
            continue;
        } else if ("d".equalsIgnoreCase(input)) {
            if (rollCount == MAX_ROLLS - 1) {
                System.out.println("Dice sequence has been deferred.");
                break;
            } else {
                System.out.println("You can only defer on the last roll.");
            }
        } else {
            try {
                ScoreCategory category = ScoreCategory.valueOf(input.toUpperCase());
                if (player.hasCategoryBeenSelected(category)) {
                    System.out.println("Category already selected. Please choose a different category.");
                    continue;
                }

                setAsideDice(diceSetAside, category);
                int score = calculateScore(category, diceSetAside);
                player.updateScore(category, score, displayDice(), currentRound);
                System.out.println("Score for " + category + ": " + score);
                currentRollSequence.append(displayDice()).append(" "); // Update the current roll sequence
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid category. Please choose a valid category.");
            }
        }
    }

    System.out.println(player.getName() + "'s current score: " + player.getTotalScore());
    player.addSequence(currentRollSequence.toString().trim()); // Store the current roll sequence
    System.out.println(); // Add an empty line to separate turns
}

    private void rollDice(boolean[] diceSetAside) {
        for (int i = 0; i < dice.length; i++) {
            if (!diceSetAside[i]) {
                dice[i].roll();
            }
        }
    }

    private void setAsideDice(boolean[] diceSetAside, ScoreCategory category) {
        for (int i = 0; i < dice.length; i++) {
            if (dice[i].getFaceValue() == category.ordinal() + 1) {
                diceSetAside[i] = true;
            }
        }
    }

    private int calculateScore(ScoreCategory category, boolean[] diceSetAside) {
        int score = 0;
        int targetNumber = category.ordinal() + 1;

        for (int i = 0; i < dice.length; i++) {
            if (diceSetAside[i] && dice[i].getFaceValue() == targetNumber) {
                score += targetNumber;
            }
        }

        return score;
    }

    private String displayDice() {
        StringBuilder sb = new StringBuilder();
        for (Dice die : dice) {
            sb.append(die.getFaceValue()).append(" ");
        }
        return sb.toString().trim();
    }

private void displayResultTable() {
    System.out.printf("%-10s %-10s %-10s\n", "Category", "Player1", "Player2");
    for (ScoreCategory category : ScoreCategory.values()) {
        if (category != ScoreCategory.SEQUENCE) {
            System.out.printf("%-10s%-12s%-12s\n", category, player1.getScore(category), player2.getScore(category));
        }
    }

   
    
    // Display sequence table only if there are sequences
    if (player1.getSequences().length > 0 && player2.getSequences().length > 0) {
        System.out.printf("%-10s %-12s %-12s\n", "SEQUENCE", Arrays.toString(player1.getSequences()), Arrays.toString(player2.getSequences()));
    }
     System.out.printf("%-10s%-12s%-12s\n", "Total", player1.getTotalScore(), player2.getTotalScore());
}

    public void startGame() {
        for (int round = 1; round <= MAX_TURNS; round++) {
            System.out.println("Round " + round);
            playTurn(player1);
            if (round < MAX_TURNS) {
                playTurn(player2);
            }
        }

        determineWinner();
        displayResultTable();
    }




    private void determineWinner() {
        int score1 = player1.getTotalScore();
        int score2 = player2.getTotalScore();
        System.out.println("Final Scores: Player 1: " + score1 + ", Player 2: " + score2);
        if (score1 > score2) {
            System.out.println("Player 1 wins!");
        } else if (score2 > score1) {
            System.out.println("Player 2 wins!");
        } else {
            System.out.println("It's a tie!");
        }
    }

    public static void main(String[] args) {
        DiceGame game = new DiceGame();
        game.startGame();
    }
}
