
package dicegame;


public enum ScoreCategory {
    ONES, TWOS, THREES, FOURS, FIVES, SIXES, SEQUENCE;
}

