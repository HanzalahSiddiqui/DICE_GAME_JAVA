package dicegame;

public class Player {
    private String name;
    private int[] scores;
    private boolean[] categoriesSelected;
private String[] sequences;
    private int currentTurn;
private int maxTurns;
// In the constructor

      public Player(String name, int maxTurns) {
        this.name = name;
        this.scores = new int[ScoreCategory.values().length];
        this.categoriesSelected = new boolean[ScoreCategory.values().length];
        this.sequences = new String[maxTurns];
        this.maxTurns = maxTurns;
        this.currentTurn = 0;
    }

       public void addSequence(String sequence) {
        if (currentTurn < maxTurns) {
            sequences[currentTurn] = sequence;
            currentTurn++;
        }
    }
   // Inside the Player class
public String[] getSequences() {
    return sequences;
}

public void updateScore(ScoreCategory category, int score, String sequence, int round) {
    int index = category.ordinal();
    if (!categoriesSelected[index]) {
        scores[index] = score;
        categoriesSelected[index] = true;
        sequences[round - 1] = sequence;
    } else {
        System.out.println("Category already selected in a previous turn.");
    }
}

    public boolean hasCategoryBeenSelected(ScoreCategory category) {
        return categoriesSelected[category.ordinal()];
    }

    public int getTotalScore() {
        int total = 0;
        for (int score : scores) {
            total += score;
        }
        return total;
    }

    public String getName() {
        return name;
    }

    public int getScore(ScoreCategory category) {
        return scores[category.ordinal()];
    }
}
